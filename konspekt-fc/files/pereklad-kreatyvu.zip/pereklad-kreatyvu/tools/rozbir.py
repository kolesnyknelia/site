"""Крок 1. Розбір ролика.

    python tools/rozbir.py ~/Downloads/rolyk.mp4

- кладе ролик у work/src.mp4 (h264, щоб далі все читалось однаково);
- пише work/info.json: ширина, висота, fps, тривалість, чи є звук;
- робить листи кадрів work/kadry_N.jpg — кадр кожні 0,5 с з підписом секунди. Їх дивимось очима:
  видно текст на екрані, сцени, де говорить людина;
- підказує смуги, де схоже на вшитий текст (білий або чорний) — для закриття написів.
"""
import shutil
import sys
from pathlib import Path

from PIL import Image, ImageDraw

from spilne import FF, WORK, duration, run, write_json

if len(sys.argv) < 2:
    raise SystemExit("Вкажіть ролик: python tools/rozbir.py шлях/до/rolyk.mp4")
src = Path(sys.argv[1]).expanduser()
if not src.exists():
    raise SystemExit(f"Немає файлу {src}")

if WORK.exists():
    shutil.rmtree(WORK)
WORK.mkdir(parents=True)
dst = WORK / "src.mp4"
run([FF, "-v", "error", "-y", "-i", str(src), "-c:v", "libx264", "-crf", "16", "-preset", "fast",
     "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-ar", "44100", str(dst)])

import re
import subprocess
err = subprocess.run([FF, "-i", str(dst)], capture_output=True, text=True).stderr
w, h = map(int, re.search(r"Video:.*?(\d{3,5})x(\d{3,5})", err).groups())
fm = re.search(r"([\d.]+) fps", err)
fps = round(float(fm.group(1))) if fm else 30
dur = duration(dst)
has_audio = "Audio:" in err
write_json(WORK / "info.json", {"width": w, "height": h, "fps": fps, "duration": round(dur, 3), "audio": has_audio})

# кадри кожні 0,5 с, мініатюри шириною 240
fdir = WORK / "f"
fdir.mkdir()
run([FF, "-v", "error", "-i", str(dst), "-vf", "fps=2,scale=240:-2", str(fdir / "%04d.jpg")])
frames = sorted(fdir.glob("*.jpg"))
tw, th = Image.open(frames[0]).size
per_sheet, cols = 20, 10
for k in range(0, len(frames), per_sheet):
    chunk = frames[k:k + per_sheet]
    sheet = Image.new("RGB", (tw * cols, th * ((len(chunk) + cols - 1) // cols)), "black")
    for i, f in enumerate(chunk):
        im = Image.open(f).convert("RGB")
        d = ImageDraw.Draw(im)
        label = f"{(k + i) * 0.5:.1f}s"
        d.rectangle([0, 0, 8 * len(label) + 6, 14], fill="black")
        d.text((3, 1), label, fill="yellow")
        sheet.paste(im, ((i % cols) * tw, (i // cols) * th))
    sheet.save(WORK / f"kadry_{k // per_sheet}.jpg", quality=85)
    print(f"kadry_{k // per_sheet}.jpg: {k * 0.5:.1f}–{(k + len(chunk) - 1) * 0.5:.1f} с")

# підказка: рядки, де в багатьох кадрах багато майже білих або майже чорних пікселів поруч зі світлими (текст)
scale = h / th
score = [0] * th
for f in frames:
    px = Image.open(f).convert("L").load()
    for y in range(th):
        bright = sum(1 for x in range(0, tw, 2) if px[x, y] > 232)
        dark = sum(1 for x in range(0, tw, 2) if px[x, y] < 25)
        if bright > 5 and (bright < tw // 2 - 10 or dark > 5):
            score[y] += 1
need = max(2, len(frames) // 5)
bands, start = [], None
for y, c in enumerate(score + [0]):
    if c >= need and start is None:
        start = y
    elif c < need and start is not None:
        if y - start >= 3:
            bands.append((int(start * scale), int(y * scale)))
        start = None

print(f"\nВідео {w}×{h}, {fps} к/с, {dur:.1f} с, звук: {'є' if has_audio else 'немає'}")
print("Можливі смуги з текстом (y від–до, px):", bands or "не знайшла — дивіться листи кадрів")
print("Далі: подивіться work/kadry_*.jpg. Є мова — python tools/rozpiznaty.py")
