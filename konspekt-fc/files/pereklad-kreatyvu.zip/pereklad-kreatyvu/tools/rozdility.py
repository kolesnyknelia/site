"""Крок 3 (лише коли в ролику говорять і є музика). Відділяємо голос від музики.

    python tools/rozdility.py

Результат — work/muzyka.wav: звук ролика без голосу (музика й шуми лишаються).
Потрібен пакет demucs (див. SKILL.md). Перший запуск завантажує модель і може йти кілька хвилин.
"""
import shutil
import subprocess
import sys

from spilne import FF, TYSHA_DB, WORK, loudness, run

wav = WORK / "zvuk.wav"
run([FF, "-v", "error", "-y", "-i", str(WORK / "src.mp4"), "-vn", "-ac", "2", "-ar", "44100", str(wav)])
out = WORK / "demucs"
r = subprocess.run([sys.executable, "-m", "demucs", "--two-stems=vocals", "-n", "htdemucs", "-o", str(out), str(wav)])
if r.returncode != 0:
    raise SystemExit("Не вдалося відділити голос. Варіант: у plan.json \"muzyka_z_rolyka\": false і своя музика (\"muzyka\").")
found = list(out.rglob("no_vocals.wav"))
if not found:
    raise SystemExit("demucs не створив no_vocals.wav")
db = loudness(found[0])
if db <= TYSHA_DB:
    (WORK / "muzyka.wav").unlink(missing_ok=True)
    print(f"Під голосом музики немає ({db:.0f} дБ) — у ролик піде вбудована музика скіла.")
else:
    shutil.copy(found[0], WORK / "muzyka.wav")
    print(f"Музика є ({db:.0f} дБ): work/muzyka.wav — без голосу. Залишаємо її.")
