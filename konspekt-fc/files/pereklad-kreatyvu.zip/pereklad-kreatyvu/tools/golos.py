"""Крок 5. Українська озвучка за work/plan.json → work/golos/*.mp3 і work/golos.json.

    python tools/golos.py           # усі фрази
    python tools/golos.py --proba   # лише перша фраза → work/proba.mp3, щоб послухати голос
    python tools/golos.py --fraza 3 # лише 3-я фраза → work/fraza_3.mp3 (перевірити виправлене слово)

Наголос: плюс перед наголошеною голосною — «с+итечко». Для голосу стане знаком наголосу, у субтитрах зникне.

Голоси: uk-UA-OstapNeural (чоловічий, за замовчуванням), uk-UA-PolinaNeural (жіночий). Потрібен інтернет.
Скрипт показує, чи фрази не налазять одна на одну і чи влазять у ролик.
"""
import asyncio
import os
import sys

import edge_tts

from spilne import WORK, duration, read_json, write_json

plan = read_json(WORK / "plan.json")
info = read_json(WORK / "info.json")
if (plan.get("montazh") or {}).get("sceny"):   # монтаж: довжина — сума сцен
    info["duration"] = round(sum(float(x["to"]) - float(x["from"]) for x in plan["montazh"]["sceny"]), 2)
g = plan.get("golos") or {}
frazy = g.get("frazy") or []
if not frazy:
    raise SystemExit("У plan.json немає golos.frazy — озвучувати нічого.")
voice = g.get("holos", "uk-UA-OstapNeural")
rate, pitch = g.get("shvydkist", "+15%"), g.get("vysota", "+0Hz")


import re

PLUS = re.compile(r"\+([аеєиіїоуюяАЕЄИІЇОУЮЯ])")


def for_voice(text):
    return PLUS.sub(lambda m: m.group(1) + "\u0301", text)


def for_eyes(text):
    return text.replace("+", "")


async def say(text, out):
    proxy = os.environ.get("HTTPS_PROXY") or os.environ.get("https_proxy") or None   # якщо інтернет через проксі
    await edge_tts.Communicate(for_voice(text), voice, rate=rate, pitch=pitch, proxy=proxy).save(str(out))


if "--fraza" in sys.argv:
    k = int(sys.argv[sys.argv.index("--fraza") + 1])
    asyncio.run(say(frazy[k - 1]["text"], WORK / f"fraza_{k}.mp3"))
    print(f"Послухайте work/fraza_{k}.mp3: {for_eyes(frazy[k - 1]['text'])}")
    sys.exit()

if "--proba" in sys.argv:
    asyncio.run(say(frazy[0]["text"], WORK / "proba.mp3"))
    print("Послухайте work/proba.mp3")
    sys.exit()

gdir = WORK / "golos"
gdir.mkdir(exist_ok=True)
for old in gdir.glob("*.mp3"):
    old.unlink()
res = []
for i, f in enumerate(frazy):
    p = gdir / f"{i:02d}.mp3"
    asyncio.run(say(f["text"], p))
    res.append({"at": float(f["at"]), "dur": round(duration(p), 3), "text": for_eyes(f["text"]), "sub": for_eyes(f.get("sub", f["text"])), "file": p.name})
write_json(WORK / "golos.json", res)

ok = True
for a, b in zip(res, res[1:] + [None]):
    end = a["at"] + a["dur"]
    print(f"{a['at']:5.1f}–{end:5.1f}  {a['text']}")
    if b and end > b["at"] - 0.15:
        print(f"   ⚠ налазить на наступну фразу ({end - b['at']:+.1f} с): посуньте at або скоротіть текст")
        ok = False
    if not b and end > info["duration"]:
        print(f"   ⚠ не влазить у ролик ({info['duration']} с): скоротіть текст")
        ok = False
print("Усе влазить ✅" if ok else "Виправте ⚠ у plan.json і запустіть ще раз")
