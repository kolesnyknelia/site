"""Крок 2. Що і якою мовою говорять у ролику.

    python tools/rozpiznaty.py            # модель small — швидко
    python tools/rozpiznaty.py medium     # точніше, повільніше

Мову визначає сам (англійська, російська, польська…). Пише work/movlennia.json і друкує фрази з секундами.
Перший запуск завантажує модель розпізнавання (small ≈ 0,5 ГБ).
"""
import os
import subprocess
import sys

os.environ.setdefault("HF_HUB_DISABLE_XET", "1")    # модель тягнемо звичайним завантаженням — стабільніше
import numpy as np
from faster_whisper import WhisperModel

from spilne import FF, WORK, write_json

# звук декодуємо своїм ffmpeg — не залежимо від версії бібліотеки av
pcm = subprocess.run([FF, "-v", "error", "-i", str(WORK / "src.mp4"), "-vn", "-ac", "1", "-ar", "16000", "-f", "s16le", "-"],
                     capture_output=True, check=True).stdout
audio = np.frombuffer(pcm, np.int16).astype(np.float32) / 32768.0

model = sys.argv[1] if len(sys.argv) > 1 else "small"
m = WhisperModel(model, device="cpu", compute_type="int8")
segs, info = m.transcribe(audio, vad_filter=True)
res = [{"start": round(s.start, 2), "end": round(s.end, 2), "text": s.text.strip()} for s in segs]
write_json(WORK / "movlennia.json", {"mova": info.language, "jmovirnist": round(info.language_probability, 2), "frazy": res})
print(f"Мова ролика: {info.language} ({info.language_probability:.0%})")
if not res:
    print("Мови не знайшла — у ролику лише музика або тиша. Озвучка не обов'язкова.")
for s in res:
    print(f"[{s['start']:.1f}–{s['end']:.1f}] {s['text']}")
