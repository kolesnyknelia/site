"""Крок 6. Збирає готовий ролик за work/plan.json.

    python tools/zbirka.py --kadr 1 4 7.5   # спершу контрольні кадри → gotovi/kadr_*.jpg
    python tools/zbirka.py                  # готовий ролик → gotovi/<nazva>.mp4

Відео не ріжемо і не зумимо. Робимо лише:
- закриваємо написи іншою мовою розмитою смугою і ставимо український текст (napysy);
- голос: замість чужого — українська озвучка (golos) і субтитри (subtytry);
- музика: з ролика без голосу (work/muzyka.wav після rozdility.py) або своя (zvuk.muzyka).
"""
import re
from pathlib import Path
import sys

from PIL import Image, ImageDraw, ImageFilter, ImageFont

from spilne import FF, OUT, WORK, font_path, read_json, run

plan = read_json(WORK / "plan.json")
info = read_json(WORK / "info.json")
W, H, DUR = info["width"], info["height"], info["duration"]
FONT = font_path(plan.get("shryft"))
TXT = WORK / "txt"
TXT.mkdir(exist_ok=True)
for old in TXT.glob("*.png"):
    old.unlink()

EMOJI = re.compile("[\U00010000-\U0010FFFF☀-➿️]")


def clean(text):
    t = EMOJI.sub("", text).replace("  ", " ").strip()
    if t != text.strip():
        print(f"   (емодзі прибрано — шрифт їх не малює): {t}")
    return t


def wrap(draw, text, font, max_w):
    lines = []
    for para in text.split("\n"):
        cur = ""
        for word in para.split():
            test = (cur + " " + word).strip()
            if draw.textlength(test, font=font) <= max_w or not cur:
                cur = test
            else:
                lines.append(cur)
                cur = word
        lines.append(cur)
    return lines


def text_png(text, size, max_w, style, name):
    """Малює текст у прозорий PNG: білий, з м'якою тінню (napys) або з чорним контуром (sub)."""
    text = clean(text)
    probe = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    while True:
        font = ImageFont.truetype(FONT, size)
        lines = wrap(probe, text, font, max_w)
        widest = max(probe.textlength(l, font=font) for l in lines)
        if (widest <= max_w and len(lines) <= 3) or size <= 14:
            break
        size -= 2
    gap = int(size * 0.22)
    lh = size + gap
    pad = int(size * 0.6)
    img = Image.new("RGBA", (int(widest) + pad * 2, lh * len(lines) - gap + pad * 2), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    stroke = max(2, size // 12) if style == "sub" else 0
    if style == "napys":   # м'яка темна тінь під текстом
        sh = Image.new("RGBA", img.size, (0, 0, 0, 0))
        sd = ImageDraw.Draw(sh)
        for i, l in enumerate(lines):
            x = (img.width - sd.textlength(l, font=font)) / 2
            sd.text((x, pad + i * lh + 2), l, font=font, fill=(0, 0, 0, 200))
        img = Image.alpha_composite(img, sh.filter(ImageFilter.GaussianBlur(size / 7)))
        d = ImageDraw.Draw(img)
    if style == "plashka":   # напівпрозора темна плашка під текстом — для тексту поверх чистого відео
        bg = Image.new("RGBA", img.size, (0, 0, 0, 0))
        ImageDraw.Draw(bg).rounded_rectangle([0, 0, img.width - 1, img.height - 1], radius=int(size * 0.5), fill=(0, 0, 0, 150))
        img = Image.alpha_composite(bg, img)
        d = ImageDraw.Draw(img)
    for i, l in enumerate(lines):
        x = (img.width - d.textlength(l, font=font)) / 2
        d.text((x, pad + i * lh), l, font=font, fill="white", stroke_width=stroke, stroke_fill="black")
    p = TXT / f"{name}.png"
    img.save(p)
    return p, img.width, img.height


def chunks(phrase):
    """Ділимо фразу озвучки на шматки по 2–3 слова для субтитрів; час — пропорційно довжині."""
    words = phrase["text"].split()
    parts, cur = [], []
    for w in words:
        cur.append(w)
        if len(cur) >= 3 or len(" ".join(cur)) >= 20 or re.search(r"[.!?,:;—]$", w):
            parts.append(" ".join(cur))
            cur = []
    if cur:
        parts.append(" ".join(cur))
    speak = max(0.3, phrase["dur"] - 0.3)
    total = sum(len(p) + 3 for p in parts)
    t, res = phrase["at"], []
    for p in parts:
        d = speak * (len(p) + 3) / total
        res.append((t, t + d, p.rstrip(",;:—")))
        t += d
    return res


inputs = ["-i", str(WORK / "src.mp4")]
vf, cur, n_in = [], "[0:v]", 1
overlays = []   # (png, x, y, from, to)

# 1. написи: закрити чужий текст розмитою смугою і/або поставити український.
#    "zakryty": false — нічого не закриваємо (чисте відео), текст на напівпрозорій плашці
for i, nb in enumerate(plan.get("napysy") or []):
    top = max(0, int(nb.get("top", H * 0.12)))
    hgt = min(int(nb.get("height", W // 6)), H - top)
    a, b = float(nb.get("from", 0)), float(nb.get("to", DUR))
    zakryty = nb.get("zakryty", True)
    if zakryty:
        blur = max(6, W // 36)
        vf.append(f"{cur}split[m{i}][c{i}];[c{i}]crop={W}:{hgt}:0:{top},gblur=sigma={blur}:steps=3,eq=brightness=-0.07[b{i}];"
                  f"[m{i}][b{i}]overlay=0:{top}:enable='between(t,{a},{b})'[n{i}]")
        cur = f"[n{i}]"
    if nb.get("text"):
        style = "napys" if zakryty or not nb.get("plashka", True) else "plashka"
        p, w, h = text_png(nb["text"], int(nb.get("rozmir", W // 18)), int(W * 0.9), style, f"napys{i}")
        overlays.append((p, (W - w) // 2, top + (hgt - h) // 2, a, b))

# 2. субтитри з озвучки
golos = read_json(WORK / "golos.json", default=[]) if (plan.get("golos") or {}).get("frazy") else []
if plan.get("golos", {}).get("frazy") and not golos:
    raise SystemExit("Спершу озвучка: python tools/golos.py")
if golos and plan.get("subtytry", True):
    y_sub = int(H * float(plan.get("subtytry_vysota", 0.72)))
    k = 0
    for ph in golos:
        for a, b, t in chunks(ph):
            p, w, h = text_png(t, W // 13, int(W * 0.86), "sub", f"sub{k}")
            overlays.append((p, (W - w) // 2, y_sub, a, b + 0.08))
            k += 1

for j, (p, x, y, a, b) in enumerate(overlays):
    inputs += ["-i", str(p)]
    vf.append(f"{cur}[{n_in}:v]overlay={x}:{y}:enable='between(t,{a:.2f},{b:.2f})'[o{j}]")
    cur, n_in = f"[o{j}]", n_in + 1
vf.append(f"{cur}format=yuv420p[vout]")

# 3. звук
zvuk = plan.get("zvuk") or {}
af, mix = [], []
if golos:
    gv = float(plan["golos"].get("guchnist", 1.0))
    for i, ph in enumerate(golos):
        inputs += ["-i", str(WORK / "golos" / ph["file"])]
        ms = int(ph["at"] * 1000)
        af.append(f"[{n_in}:a]adelay={ms}|{ms},volume={gv}[g{i}]")
        mix.append(f"[g{i}]")
        n_in += 1
    sep = WORK / "muzyka.wav"
    if zvuk.get("muzyka_z_rolyka", True) and sep.exists():
        inputs += ["-i", str(sep)]
        af.append(f"[{n_in}:a]volume={zvuk.get('muzyka_guchnist', 0.6)}[bed]")
        mix.append("[bed]")
        n_in += 1
    elif zvuk.get("muzyka"):
        inputs += ["-stream_loop", "-1", "-i", str(Path(zvuk["muzyka"]).expanduser())]
        v = zvuk.get("muzyka_guchnist", 0.25)
        af.append(f"[{n_in}:a]atrim=0:{DUR},volume={v},afade=t=in:d=0.4,afade=t=out:st={max(0, DUR - 0.8)}:d=0.8[bed]")
        mix.append("[bed]")
        n_in += 1
    else:
        print("   Без музики: немає work/muzyka.wav і не вказано zvuk.muzyka")
else:
    if info.get("audio") and zvuk.get("rolyk", 1.0) > 0:
        af.append(f"[0:a]volume={zvuk.get('rolyk', 1.0)}[orig]")
        mix.append("[orig]")
    if zvuk.get("muzyka"):   # ролик без звуку або тихий — додаємо свою музику
        inputs += ["-stream_loop", "-1", "-i", str(Path(zvuk["muzyka"]).expanduser())]
        v = zvuk.get("muzyka_guchnist", 0.5)
        af.append(f"[{n_in}:a]atrim=0:{DUR},volume={v},afade=t=in:d=0.4,afade=t=out:st={max(0, DUR - 0.8)}:d=0.8[bed]")
        mix.append("[bed]")
        n_in += 1
if mix:
    af.append(f"{''.join(mix)}amix=inputs={len(mix)}:normalize=0:duration=longest,atrim=0:{DUR},alimiter=limit=0.95[aout]")
else:
    af.append(f"anullsrc=r=44100:cl=stereo,atrim=0:{DUR}[aout]")

OUT.mkdir(exist_ok=True)
base = [FF, "-v", "error", "-y"] + inputs + ["-filter_complex", ";".join(vf + af)]

if "--kadr" in sys.argv:
    base = [FF, "-v", "error", "-y"] + inputs + ["-filter_complex", ";".join(vf)]
    times = [float(x) for x in sys.argv[sys.argv.index("--kadr") + 1:]] or [1.0]
    for t in times:
        dst = OUT / f"kadr_{t:g}.jpg"
        run(base + ["-map", "[vout]", "-ss", str(t), "-frames:v", "1", "-q:v", "3", str(dst)])
        print(dst)
    sys.exit()

name = re.sub(r"[^\w-]+", "-", plan.get("nazva", "kreatyv-ua")).strip("-") or "kreatyv-ua"
dst = OUT / f"{name}.mp4"
run(base + ["-map", "[vout]", "-map", "[aout]", "-c:v", "libx264", "-crf", "19", "-preset", "medium",
            "-c:a", "aac", "-b:a", "192k", "-t", str(DUR), "-movflags", "+faststart", str(dst)])
print(f"Готово: {dst}")
