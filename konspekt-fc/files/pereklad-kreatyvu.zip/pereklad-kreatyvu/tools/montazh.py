"""Монтаж креативу з чужого ролика: свої сцени в своєму порядку, квадрат (або 9:16 / 4:5),
хук угорі, плашка внизу, закриття чужого тексту, музика, озвучка й субтитри.

    python tools/montazh.py --kadr 1 6 12   # контрольні кадри → gotovi/kadr_*.jpg
    python tools/montazh.py                 # готовий ролик → gotovi/<nazva>.mp4

Читає work/plan.json → блок "montazh" (формат — references/plan.md). Озвучка — з work/golos.json
(спершу python tools/golos.py; секунди фраз — у часі ГОТОВОГО ролика).
"""
import re
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

from spilne import FF, MUZYKA, OUT, WORK, font_path, read_json, run

plan = read_json(WORK / "plan.json")
info = read_json(WORK / "info.json")
M = plan.get("montazh") or {}
sceny = M.get("sceny") or []
if not sceny:
    raise SystemExit("У plan.json немає montazh.sceny")
FONT = font_path(plan.get("shryft"))
FMT = {"1:1": (1080, 1080), "4:5": (1080, 1350), "9:16": (1080, 1920)}[M.get("format", "1:1")]
SW, SH = FMT
k = M.get("kadr") or {}
CX, CY = int(k.get("x", 0)), int(k.get("y", 0))
CW = int(k.get("w", info["width"] - CX)) // 2 * 2
CH = int(k.get("h", info["height"] - CY)) // 2 * 2
FG_W, FG_H = SW, round(SW * CH / CW / 2) * 2         # картинка на всю ширину
if FG_H > SH - 300:                                 # висока картинка — зменшуємо, щоб лишилось місце під текст
    FG_H = SH - 300
    FG_W = round(FG_H * CW / CH / 2) * 2
FG_X = (SW - FG_W) // 2
TOP_ZONE = max(180, (SH - FG_H) * 11 // 20)          # трохи більше місця під хук, ніж під плашку
FG_Y = min(TOP_ZONE, SH - FG_H)
EMO = re.compile("[\U00010000-\U0010FFFF☀-➿️]")
TXT = WORK / "txt_m"
TXT.mkdir(exist_ok=True)
for o in TXT.glob("*.png"):
    o.unlink()


def lines_for(text, f, max_w, d):
    out, cur = [], ""
    for w in text.split():
        t = (cur + " " + w).strip()
        if d.textlength(t, font=f) <= max_w or not cur:
            cur = t
        else:
            out.append(cur)
            cur = w
    return out + [cur]


def text_png(text, size, max_w, name, kind):
    """kind: hook — великий білий з тінню; plashka — темний текст на світлій плашці; sub — білий з контуром."""
    text = EMO.sub("", text).strip()
    d = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    base = size
    while True:
        f = ImageFont.truetype(FONT, size)
        ls = lines_for(text, f, max_w, d)
        if len(ls) == 1 or size < 28 or (size <= base - 16 and len(ls) <= 2):
            break
        size -= 4
    widest = max(d.textlength(l, font=f) for l in ls)
    lh, pad = int(size * 1.2), int(size * 0.45)
    img = Image.new("RGBA", (SW, lh * len(ls) + pad * 2), (0, 0, 0, 0))
    if kind == "plashka":
        bw = int(widest + pad * 2.2)
        ImageDraw.Draw(img).rounded_rectangle([(SW - bw) // 2, 0, (SW + bw) // 2, img.height - 1], radius=size // 2, fill=(255, 255, 255, 238))
    if kind == "hook":
        sh = Image.new("RGBA", img.size, (0, 0, 0, 0))
        sd = ImageDraw.Draw(sh)
        for i, l in enumerate(ls):
            sd.text(((SW - sd.textlength(l, font=f)) / 2, pad + i * lh + 3), l, font=f, fill=(0, 0, 0, 230))
        img = Image.alpha_composite(img, sh.filter(ImageFilter.GaussianBlur(6)))
    dd = ImageDraw.Draw(img)
    for i, l in enumerate(ls):
        x = (SW - dd.textlength(l, font=f)) / 2
        y = pad + i * lh - size * 0.08
        if kind == "plashka":
            dd.text((x, y), l, font=f, fill=(40, 30, 20, 255))
        else:
            dd.text((x, y), l, font=f, fill="white", stroke_width=(max(2, size // 14) if kind == "sub" else 0), stroke_fill="black")
    p = TXT / f"{name}.png"
    img.save(p)
    return p, img.height


def label_png(text, name):
    f = ImageFont.truetype(FONT, 40)
    d = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    tw = d.textlength(text, font=f)
    img = Image.new("RGBA", (int(tw + 48), 72), (0, 0, 0, 0))
    dd = ImageDraw.Draw(img)
    dd.rounded_rectangle([0, 0, img.width - 1, 71], radius=20, fill=(255, 255, 255, 240))
    dd.text((24, 12), text, font=f, fill=(40, 30, 20, 255))
    p = TXT / f"{name}.png"
    img.save(p)
    return p, img.width, img.height


golos = read_json(WORK / "golos.json", default=[]) if (plan.get("golos") or {}).get("frazy") else []
if (plan.get("golos") or {}).get("frazy") and not golos:
    raise SystemExit("Спершу озвучка: python tools/golos.py")
sc = SW / CW

inputs, fc, outs, n = ["-i", str(WORK / "src.mp4")], [], [], 1
t_acc = 0.0
for i, s in enumerate(sceny):
    a, b = float(s["from"]), float(s["to"])
    d = b - a
    fc.append(f"[0:v]trim={a}:{b},setpts=PTS-STARTPTS,crop={CW}:{CH}:{CX}:{CY}[c{i}]")
    cur = f"[c{i}]"
    for j, z in enumerate(s.get("zakryty") or []):   # [x, y, w, h] у пікселях ВИХІДНОГО ролика
        x, y, w, h = (int(v) for v in z)
        x, y = max(0, x - CX), max(0, y - CY)
        w, h = min(w, CW - x) // 2 * 2, min(h, CH - y) // 2 * 2
        if w < 4 or h < 4:
            continue
        fc.append(f"{cur}split[p{i}_{j}][q{i}_{j}];[q{i}_{j}]crop={w}:{h}:{x}:{y},gblur=sigma=14:steps=3[r{i}_{j}];"
                  f"[p{i}_{j}][r{i}_{j}]overlay={x}:{y}[x{i}_{j}]")
        cur = f"[x{i}_{j}]"
    fc.append(f"{cur}fps=30,split[f{i}][g{i}];"
              f"[g{i}]scale={SW}:{SH}:force_original_aspect_ratio=increase,crop={SW}:{SH},gblur=sigma=40,eq=brightness=-0.18:saturation=0.8[bg{i}];"
              f"[f{i}]scale={FG_W}:{FG_H}[fg{i}];[bg{i}][fg{i}]overlay={FG_X}:{FG_Y}[s{i}]")
    cur = f"[s{i}]"
    over = []
    for j, m in enumerate(s.get("mitky") or []):   # українська мітка на місці чужого напису
        p, lw, lh = label_png(EMO.sub("", m["text"]).strip(), f"m{i}_{j}")
        cx = FG_X + int((float(m["x"]) - CX) * FG_W / CW) - lw // 2
        cy = FG_Y + int((float(m["y"]) - CY) * FG_H / CH) - lh // 2
        over.append((p, max(0, min(SW - lw, cx)), max(0, cy)))
    if s.get("hook"):
        p, h = text_png(s["hook"], 76, SW - 80, f"h{i}", "hook")
        over.append((p, 0, max(16, (FG_Y - h) // 2)))
    if s.get("plashka") and not golos:
        p, h = text_png(s["plashka"], 46, SW - 180, f"b{i}", "plashka")
        over.append((p, 0, FG_Y + FG_H + (SH - FG_Y - FG_H - h) // 2))
    for j, (p, x, y) in enumerate(over):
        inputs += ["-loop", "1", "-t", f"{d:.3f}", "-i", str(p)]
        fc.append(f"[{n}:v]format=rgba,fade=t=in:st=0:d=0.2:alpha=1[o{i}_{j}];{cur}[o{i}_{j}]overlay={x}:{y}:shortest=1[w{i}_{j}]")
        cur, n = f"[w{i}_{j}]", n + 1
    fc.append(f"{cur}setsar=1,format=yuv420p[v{i}]")
    outs.append(f"[v{i}]")
    t_acc += d
TOTAL = round(t_acc, 3)
fc.append(f"{''.join(outs)}concat=n={len(sceny)}:v=1:a=0[vc]")
cur = "[vc]"

# субтитри озвучки — внизу, замість плашок
if golos and plan.get("subtytry", True):
    sub_y = FG_Y + FG_H + 20
    kk = 0
    for ph in golos:
        words = ph.get("sub", ph["text"]).split()
        parts, c = [], []
        for w in words:
            c.append(w)
            if len(c) >= 3 or len(" ".join(c)) >= 20 or re.search(r"[.!?,:;—]$", w):
                parts.append(" ".join(c)); c = []
        if c:
            parts.append(" ".join(c))
        speak = max(0.3, ph["dur"] - 0.3)
        tot = sum(len(x) + 3 for x in parts)
        t = ph["at"]
        for x in parts:
            dd = speak * (len(x) + 3) / tot
            p, h = text_png(x.rstrip(",;:—"), 58, SW - 120, f"s{kk}", "sub")
            inputs += ["-i", str(p)]
            fc.append(f"{cur}[{n}:v]overlay=0:{sub_y}:enable='between(t,{t:.2f},{t + dd + 0.08:.2f})'[z{kk}]")
            cur, n, t, kk = f"[z{kk}]", n + 1, t + dd, kk + 1
fc.append(f"{cur}format=yuv420p[vout]")

# звук: озвучка + музика скіла (або своя)
zvuk = plan.get("zvuk") or {}
af, mix = [], []
for i, ph in enumerate(golos):
    inputs += ["-i", str(WORK / "golos" / ph["file"])]
    ms = int(ph["at"] * 1000)
    af.append(f"[{n}:a]adelay={ms}|{ms},volume={plan['golos'].get('guchnist', 1.0)}[g{i}]")
    mix.append(f"[g{i}]")
    n += 1
if not zvuk.get("bez_muzyky"):
    styl = str(zvuk.get("styl", "1"))
    mp = Path(zvuk["muzyka"]).expanduser() if zvuk.get("muzyka") else next(iter(sorted(MUZYKA.glob(f"{styl}-*.mp3")) + sorted(MUZYKA.glob(f"*-{styl}.mp3"))), None)
    if mp and mp.exists():
        vol = zvuk.get("muzyka_guchnist", 0.25 if golos else 0.85)
        inputs += ["-stream_loop", "-1", "-i", str(mp)]
        af.append(f"[{n}:a]atrim=0:{TOTAL},volume={vol},afade=t=in:d=0.3,afade=t=out:st={max(0, TOTAL - 1.2)}:d=1.2[bed]")
        mix.append("[bed]")
        n += 1
        print(f"   Музика: {mp.name}")
af.append(f"{''.join(mix)}amix=inputs={len(mix)}:normalize=0,atrim=0:{TOTAL},alimiter=limit=0.95[aout]" if mix
          else f"anullsrc=r=44100:cl=stereo,atrim=0:{TOTAL}[aout]")

OUT.mkdir(exist_ok=True)
if "--kadr" in sys.argv:
    times = [float(x) for x in sys.argv[sys.argv.index("--kadr") + 1:]] or [1.0]
    for t in times:
        dst = OUT / f"kadr_{t:g}.jpg"
        run([FF, "-v", "error", "-y"] + inputs + ["-filter_complex", ";".join(fc), "-map", "[vout]", "-ss", str(t), "-frames:v", "1", "-q:v", "3", str(dst)])
        print(dst)
    sys.exit()

name = re.sub(r"[^\w-]+", "-", plan.get("nazva", "kreatyv-ua")).strip("-") or "kreatyv-ua"
dst = OUT / f"{name}.mp4"
run([FF, "-v", "error", "-y"] + inputs + ["-filter_complex", ";".join(fc + af), "-map", "[vout]", "-map", "[aout]",
     "-c:v", "libx264", "-crf", "20", "-preset", "medium", "-c:a", "aac", "-b:a", "160k", "-t", str(TOTAL),
     "-movflags", "+faststart", str(dst)])
print(f"Готово: {dst} · {TOTAL:.1f} с · {SW}×{SH}")
