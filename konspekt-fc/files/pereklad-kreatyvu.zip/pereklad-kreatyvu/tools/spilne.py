"""Спільне для всіх скриптів скіла «Переклад креативу»: шляхи, ffmpeg, шрифт, тривалість."""
import json
import re
import subprocess
from pathlib import Path

import imageio_ffmpeg

FF = imageio_ffmpeg.get_ffmpeg_exe()
ROOT = Path(__file__).resolve().parent.parent   # робоча папка ~/pereklad-kreatyvu
WORK = ROOT / "work"
OUT = ROOT / "gotovi"

# Шрифти з кирилицею, які зазвичай уже є на комп'ютері
FONT_CANDIDATES = [
    "/System/Library/Fonts/Supplemental/Arial Bold.ttf",       # Mac
    "/Library/Fonts/Arial Bold.ttf",
    "/System/Library/Fonts/Supplemental/Arial.ttf",
    "C:/Windows/Fonts/arialbd.ttf",                           # Windows
    "C:/Windows/Fonts/segoeuib.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",   # Linux
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
]


def font_path(custom=None):
    for p in ([custom] if custom else []) + FONT_CANDIDATES:
        if p and Path(p).expanduser().exists():
            return str(Path(p).expanduser())
    raise SystemExit("Не знайшла шрифт з кирилицею. Вкажіть у plan.json: \"shryft\": \"шлях/до/шрифту.ttf\"")


def duration(path) -> float:
    err = subprocess.run([FF, "-i", str(path)], capture_output=True, text=True).stderr
    m = re.search(r"Duration: (\d+):(\d+):([\d.]+)", err)
    if not m:
        raise SystemExit(f"Не можу прочитати тривалість: {path}")
    h, mi, s = m.groups()
    return int(h) * 3600 + int(mi) * 60 + float(s)


def read_json(path, default=None):
    p = Path(path)
    if not p.exists():
        if default is not None:
            return default
        raise SystemExit(f"Немає файлу {p}")
    return json.loads(p.read_text(encoding="utf-8"))


def write_json(path, data):
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")


def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit("ffmpeg помилка:\n" + r.stderr[-2500:])
    return r
