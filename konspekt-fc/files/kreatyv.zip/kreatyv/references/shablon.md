# Шаблони промпту для генератора

Заповни `<…>`, дужки прибери. Порядок блоків не міняй. Елементів у блоці LAYOUT — стільки, скільки на прикладі.

## Як у прикладі (основний)

```
CREATE A FINISHED <VERTICAL / SQUARE> AD BANNER. TWO IMAGES ARE ATTACHED:
IMAGE 1 = MY PRODUCT (<що це, 2–4 слова>). IMAGE 2 = LAYOUT EXAMPLE (<що на прикладі, 2–4 слова>).
COPY THE LAYOUT, SCENE, LIGHT, FONTS, PANELS, ICONS AND COLOURS OF IMAGE 2 AS CLOSELY AS POSSIBLE,
BUT REPLACE ITS PRODUCT WITH THE PRODUCT FROM IMAGE 1 AND ITS TEXT WITH THE TEXT BELOW.
NEVER TAKE THE PRODUCT, ITS <риси чужого товару: колір, ручка, деталі> FROM IMAGE 2.

THIS WHOLE BRIEF IS A SPECIFICATION, NOT CONTENT. NEVER DRAW ANY OF ITS WORDS, NUMBERS,
PIXEL VALUES, COLOUR NAMES, FONT NAMES OR SECTION TITLES. THE ONLY TEXT IN THE IMAGE IS
THE TEXT BLOCK BELOW. NO EMOJI.

— CANVAS —
<VERTICAL 2:3 (1024 × 1536 PX). THE TOP 9% AND BOTTOM 9% ARE BACKGROUND ONLY — IT WILL BE CROPPED TO 4:5 / 1:1 (1080 × 1080 PX) / 9:16 (1080 × 1920 PX)>,
SAME ELEMENT POSITIONS AND PROPORTIONS AS IMAGE 2.
KEEP AT LEAST 60 PX OF BACKGROUND BETWEEN ANY TEXT AND THE EDGE. NOTHING CROPPED.
<тільки для 9:16: THE TOP 270 PX AND BOTTOM 670 PX ARE COVERED BY THE APP — BACKGROUND ONLY THERE.>

— TEXT IN THE IMAGE (UKRAINIAN, CHARACTER FOR CHARACTER, ONLY THESE LINES) —
KEEP І, Ї, Є, Ґ AND APOSTROPHES. NEVER HYPHENATE OR BREAK A WORD.
NO RUSSIAN LETTERS Ы Э Ъ Ё. NEVER COPY ANY TEXT FROM IMAGE 2.
WORDS WITH І, Ї, Є, Ґ — DRAW THESE LETTERS EXACTLY: <слова через кому>
<ROLE 1>: <текст>
<ROLE 2>: <текст>
<…стільки рядків, скільки текстів на прикладі>

— LAYOUT, ELEMENT BY ELEMENT (AS IN IMAGE 2) —
1. <ЕЛЕМЕНТ>: <де: клітинка сітки, вирівнювання, чи від краю>, <розмір: % ширини>.
   <форма і заливка плашки>. <шрифт: жирність, ширина, великі/малі>, <колір>. <який рядок тексту>.
2. <…>
<останнім пунктом — що прибрано: NO DIMENSION ARROWS / NO PRICE / NO LOGO, якщо на прикладі було, а в нас немає>

— PRODUCT (FROM IMAGE 1, EXACTLY) —
EXACTLY 1 <товар>: <форма>, <матеріал і колір кожної частини>, <усі деталі і їх кількість>.
COLOUR: <колір> — NOT <колір товару з прикладу>. <ЧАСТИНА> IS <як у нас> — NOT <як на прикладі>.
IT HAS NO <чого немає, але є на товарі прикладу>. NO LOGOS, LETTERS OR DIGITS ON IT.

— SCENE (AS IN IMAGE 2) —
<фон і кожен предмет: що, де, колір>. <світло: звідки, тепле/холодне, м'яке>. <глибина різкості>.
THE PRODUCT STANDS <де в кадрі>, ABOUT <N>% OF THE WIDTH, <ракурс>.
REAL CONTACT SHADOWS. PHOTOREALISTIC, NOT 3D RENDER.

— SELF-CHECK —
LAYOUT MATCHES IMAGE 2: <перелік елементів з місцями одним рядком>?
ONLY THE LINES FROM THE TEXT BLOCK, UKRAINIAN, SPELLED EXACTLY, LETTER BY LETTER?
EVERY І HAS A DOT, EVERY Ї HAS TWO DOTS, NO И WHERE І SHOULD BE, NO Ы Э Ъ Ё?
PRODUCT IS <колір, ключова деталь>, EXACTLY <N>, SAME AS IMAGE 1, NOT THE PRODUCT OF IMAGE 2?
NO BUTTON, PRICE, STAR, LOGO OR EXTRA TEXT?
IF NOT — FIX THE LAYOUT OR TEXT, NEVER THE PRODUCT.

— AVOID —
<риси товару з прикладу через ·> · PRODUCT FROM IMAGE 2 · TEXT FROM IMAGE 2 · RUSSIAN OR ENGLISH TEXT ·
EXTRA TEXT · PRICE · DISCOUNT · STARS · BUTTONS · LOGOS · WATERMARKS · CROPPED PRODUCT ·
TEXT AT THE EDGE · BROKEN WORDS · DRAWN CODES · 3D LOOK
```

### Приклад заповнення

Приклад — чайник зі свистком (м'ятний, дерев'яна ручка, «ЧАЙНИК / со свистком», картка «для всех типов плит», 2 плашки, круг «3 литра», стрілки 23 см і 20 см). Товар учня — скляний заварник 750 мл.

| № | Елемент прикладу | Текст прикладу | Наш текст |
|---|---|---|---|
| 1 | Заголовок, верх-ліво, на напівпрозорій білій плашці | ЧАЙНИК | ЗАВАРНИК |
| 2 | Підзаголовок під ним | со свистком | ЗІ СИТЕЧКОМ |
| 3 | Картка з іконкою плити, ліворуч | для всех типов плит | іконка посудомийки · можна в посудомийку |
| 4 | Плашка 1, праворуч | нержавеющая сталь | боросилікатне скло |
| 5 | Плашка 2, праворуч | термостойкая ручка | витримує окріп |
| 6 | Коричневий круг, низ-право | 3 литра | 750 мл |
| 7 | Стрілки з розмірами | 23 см · 20 см | розмірів на сайті немає → прибрано (або запитати учня) |

Заборони для товару: `THE HANDLE IS GLASS — NOT WOODEN · NOT MINT · NO WHISTLE · NOT A ROUND KETTLE`.

## Без прикладу

```
CREATE A FINISHED SQUARE FACEBOOK AND INSTAGRAM AD FOR THE PRODUCT IN THE ATTACHED PHOTO.

THIS WHOLE BRIEF IS A SPECIFICATION, NOT CONTENT. NEVER DRAW ANY OF ITS WORDS, NUMBERS,
PIXEL VALUES, COLOUR CODES, FONT NAMES OR SECTION TITLES. THE ONLY TEXT IN THE IMAGE IS
THE TEXT BLOCK BELOW. NO EMOJI.

— CANVAS —
1080 × 1080 PX (1:1). KEEP A CLEAN 100 PX BORDER OF BACKGROUND ON EVERY SIDE.
EVERY LETTER, PANEL, LINE AND THE WHOLE PRODUCT STAY INSIDE IT, NOTHING CROPPED.

— TEXT IN THE IMAGE (UKRAINIAN, CHARACTER FOR CHARACTER, <N> LINES ONLY) —
KEEP І, Ї, Є, Ґ AND APOSTROPHES. NEVER HYPHENATE OR BREAK A WORD.
HEADLINE: <до 7 слів>
PILL: <одна цифра або факт>
LABEL 1 → <деталь>: <2–4 слова>
LABEL 2 → <деталь>: <2–4 слова>

— PRODUCT —
EXACTLY THE PRODUCT FROM THE PHOTO: <форма, матеріал, усі частини>. COLOUR: <колір> — NOT <часта помилка>.
EXACTLY <N> PIECES. NO LOGOS, LETTERS OR DIGITS ON IT.

— SCENE —
<місце, світло, ракурс>. THE PRODUCT IS LARGE AND SHARP, ABOUT 55% OF THE FRAME.
REAL CONTACT SHADOWS. PHOTOREALISTIC, NOT 3D RENDER. <ідея: було → стало / доказ / здивування>

— TEXT STYLE —
ONE BOLD ROUNDED SANS TYPEFACE. HEADLINE <колір>, BOLDEST. PANELS: <форма, заливка>.
LABEL LINES THIN, ENDING AT THE EDGE OF THE PART. ACCENT <колір> ONLY ON <одне місце>.

— SELF-CHECK —
ONLY THE LINES FROM THE TEXT BLOCK? PRODUCT <колір>, <N> PIECES, SAME AS THE PHOTO?
NOTHING CLOSER THAN 100 PX TO AN EDGE? NO BUTTON, PRICE, STAR OR LOGO?

— AVOID —
WRONG PRODUCT COLOUR · EXTRA OR MISSING PARTS · TEXT ON THE PRODUCT · EXTRA TEXT · PRICE ·
DISCOUNT · STARS · BUTTONS · LOGOS · WATERMARKS · CROPPED PRODUCT · BROKEN WORDS · 3D LOOK
```

## Тільки текст поверх готового фото

Фото товару в сцені вже гарне і перемальовувати не треба — перші рядки замінити на:

```
THE ATTACHED PHOTO IS FINAL. ADD ONLY TEXT AND PANELS ON TOP OF IT, LAID OUT AS IN THE EXAMPLE.
DO NOT REDRAW, RECOLOUR, MOVE OR CROP THE PHOTO OR THE PRODUCT.
IF A PANEL WOULD COVER THE PRODUCT — MOVE THE PANEL.
```
і прибрати блоки PRODUCT і SCENE.
