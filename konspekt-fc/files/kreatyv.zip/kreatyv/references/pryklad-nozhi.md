# Перевірений приклад: набір ножів → заварник

За цим промптом ChatGPT зробив правильний креатив: макет прикладу, товар учня, текст українською. Пиши свої промпти з такою самою детальністю.

Приклад вертикальний, а креатив — **квадрат 1:1**, як завжди: ті самі елементи в тому самому порядку, переставлені компактніше.

**Приклад:** вертикальний банер набору кухонних ножів, російською, 2:3. Темна кухня, великий заголовок із засічками, кремова плашка, бейдж-печатка «6 предметов», 3 переваги з іконками ліворуч, наліпка «Идеальный подарок», темна смуга «В наборе» з 6 колонками.
**Товар учня:** скляний заварник Edenberg 750 мл (сайт: скло витримує окріп, сталеве ситечко, можна в посудомийку, у подарунок, комплект — чайник, ситечко, кришка).

## Розбір і заміна

| № | Елемент | Де і як виглядає | Текст прикладу | Наш текст |
|---|---|---|---|---|
| 1 | Верхній рядок | По центру вгорі, дрібні рознесені великі літери, кремовий | СТИЛЬ • КАЧЕСТВО • УДОБСТВО | СКЛО • СТАЛЬ • ПІРАМІДНА ФОРМА |
| 2 | Заголовок | Величезний контрастний шрифт із засічками, білий з металевим блиском, ~85% ширини | НАБОР | ЗАВАРНИК |
| 3 | Рядок 2 | Той самий шрифт, золотий градієнт | КУХОННЫХ НОЖЕЙ | ДЛЯ ЛИСТОВОГО ЧАЮ |
| 4 | Плашка | Кремова «пігулка», темно-коричневі великі літери | ВСЁ, ЧТО НУЖНО НА КУХНЕ | ЧАЙ БЕЗ ЧАЇНОК |
| 5 | Бейдж | Праворуч, кремове коло з фігурним краєм, як печатка | 6 / предметов / ♡ | 750 / МЛ / ♡ |
| 6 | 3 переваги | Ліворуч: темне коло із золотим обідком і білою іконкою, жирна назва, дрібний опис | Нержавеющая сталь / Удобные ручки / Стильная подставка | ТЕРМОСТІЙКЕ СКЛО / СТАЛЕВЕ СИТЕЧКО / МОЖНА В ПОСУДОМИЙКУ |
| 7 | Наліпка | Праворуч, рваний кремовий папір, рукописний шрифт | Идеальный подарок / для себя и близких | У подарунок / на свято чи новосілля |
| 8 | Смуга внизу | Темна смуга, рукописний заголовок зі стрілкою, колонки з іконками | В наборе: 6 предметів з розмірами | У комплекті: 3 колонки |
| 9 | Логотип на товарі | «Kitchen PREMIUM» | — | прибрано |

Формат: приклад 2:3 → квадрат 1:1. Заголовок і плашка вгорі, переваги ліворуч і бейдж з наліпкою праворуч — ближче до товару, смуга внизу; описи переваг коротші, товар ~40% ширини.

Що змінено: 3 колонки замість 6 (у комплекті 3 речі); «Ідеальний» прибрано (обіцянка, на сайті — «у подарунок»); ніж перед підставкою → купка сухого чаю (не чашка — щоб не здавалося, що вона в комплекті); помідори й часник → лимон, м'ята, мед, кориця.

Прикріпити: **першою** — фото заварника, **другою** — приклад з ножами.

## Промпт

```
CREATE A FINISHED SQUARE 1:1 AD BANNER. TWO IMAGES ARE ATTACHED:
IMAGE 1 = MY PRODUCT (A GLASS TEAPOT). IMAGE 2 = LAYOUT EXAMPLE (A KITCHEN KNIFE SET).
COPY THE LAYOUT, SCENE MOOD, LIGHT, FONTS, PANELS, ICONS AND COLOURS OF IMAGE 2 AS CLOSELY AS POSSIBLE,
BUT REPLACE ITS PRODUCT WITH THE TEAPOT FROM IMAGE 1 AND ITS TEXT WITH THE TEXT BELOW.
NEVER TAKE THE KNIVES, THE BLACK KNIFE BLOCK, THE SCISSORS OR THE "KITCHEN PREMIUM" LOGO FROM IMAGE 2.
NEVER COPY ANY TEXT FROM IMAGE 2.

THIS WHOLE BRIEF IS A SPECIFICATION, NOT CONTENT. NEVER DRAW ANY OF ITS WORDS, NUMBERS,
PIXEL VALUES, COLOUR NAMES, FONT NAMES OR SECTION TITLES. THE ONLY TEXT IN THE IMAGE IS
THE TEXT BLOCK BELOW. NO EMOJI.

— CANVAS —
SQUARE 1:1 (1080 × 1080 PX). THE IMAGE MUST BE SQUARE, NOT VERTICAL.
IMAGE 2 IS VERTICAL. REARRANGE ALL ITS ELEMENTS INTO THE SQUARE IN THE SAME ORDER
(TOP TO BOTTOM, LEFT AND RIGHT OF THE PRODUCT), MORE COMPACT.
KEEP AT LEAST 60 PX BETWEEN ANY TEXT AND THE EDGE. NOTHING CROPPED.

— TEXT IN THE IMAGE (UKRAINIAN, CHARACTER FOR CHARACTER, ONLY THESE LINES) —
KEEP І, Ї, Є AND APOSTROPHES. NEVER HYPHENATE OR BREAK A WORD.
NO RUSSIAN LETTERS Ы Э Ъ Ё.
WORDS WITH І, Ї — DRAW THESE LETTERS EXACTLY: ПІРАМІДНА, ЧАЇНОК, ТЕРМОСТІЙКЕ, ЧАЇНКУ, У КОМПЛЕКТІ, НОВОСІЛЛЯ
TOP LINE: СКЛО • СТАЛЬ • ПІРАМІДНА ФОРМА
HEADLINE: ЗАВАРНИК
HEADLINE LINE 2: ДЛЯ ЛИСТОВОГО ЧАЮ
PILL: ЧАЙ БЕЗ ЧАЇНОК
BADGE: 750 / МЛ
BENEFIT 1 TITLE: ТЕРМОСТІЙКЕ СКЛО
BENEFIT 1 TEXT: витримує окріп
BENEFIT 2 TITLE: СТАЛЕВЕ СИТЕЧКО
BENEFIT 2 TEXT: тримає кожну чаїнку
BENEFIT 3 TITLE: МОЖНА В ПОСУДОМИЙКУ
BENEFIT 3 TEXT: легко мити
STICKER LINE 1: У подарунок
STICKER LINE 2: на свято чи новосілля
STRIP TITLE: У комплекті:
ITEM 1: ЧАЙНИК / 750 мл
ITEM 2: СИТЕЧКО / сталь
ITEM 3: КРИШКА / сталь

— LAYOUT, ELEMENT BY ELEMENT (AS IN IMAGE 2) —
1. TOP LINE: CENTRED AT THE TOP, SMALL WIDELY LETTER-SPACED CAPITALS, CREAM,
   WORDS SEPARATED BY SMALL DOTS.
2. HEADLINE: CENTRED BELOW, HUGE HIGH-CONTRAST SERIF CAPITALS, ABOUT 70% OF THE WIDTH,
   WHITE WITH A SOFT SILVER METALLIC SHEEN AND A SUBTLE SHADOW.
3. HEADLINE LINE 2: CENTRED UNDER IT, SAME SERIF CAPITALS, ABOUT HALF THE SIZE,
   WARM GOLD-TO-CREAM GRADIENT.
4. PILL: CENTRED UNDER THE HEADLINE, A WIDE ROUNDED CREAM-BEIGE GRADIENT PILL WITH DARK BROWN
   SANS CAPITALS.
5. BADGE: RIGHT SIDE, LEVEL WITH THE TOP OF THE TEAPOT, A CREAM CIRCLE WITH A SCALLOPED STAMP-LIKE
   EDGE AND A THIN INNER RING. "750" BIG DARK BROWN, "МЛ" SMALL BELOW, A TINY DARK HEART UNDER IT.
6. BENEFITS: LEFT COLUMN NEXT TO THE TEAPOT, THREE COMPACT ROWS STACKED. EACH ROW: A DARK CIRCLE WITH A THIN GOLD RING AND
   A WHITE THIN-LINE ICON (ROW 1 A FLAME, ROW 2 A MESH STRAINER, ROW 3 WATER DROPS), THEN THE
   TITLE IN BOLD WHITE SANS CAPITALS ON TWO LINES AND THE TEXT IN SMALL LIGHT GREY BELOW.
7. STICKER: RIGHT SIDE, LOWER MIDDLE, NEXT TO THE TEAPOT, A CREAM TORN-PAPER LABEL TILTED SLIGHTLY.
   LINE 1 IN DARK BROWN HANDWRITTEN SCRIPT WITH A SMALL OUTLINED HEART, LINE 2 SMALLER.
8. STRIP: A SLIM DARK BAND ACROSS THE BOTTOM, ABOUT 15% OF THE HEIGHT. ON THE LEFT THE STRIP TITLE IN CREAM
   HANDWRITTEN SCRIPT WITH A SMALL CURLY ARROW. THEN 3 EQUAL COLUMNS SEPARATED BY THIN VERTICAL
   LINES: EACH WITH A WHITE THIN-LINE ICON (A GLASS TEAPOT, A CYLINDRICAL MESH INFUSER, A LID
   WITH A BALL KNOB), THE NAME IN SMALL WHITE CAPITALS AND THE SECOND LINE BELOW IN SMALLER TEXT.
9. NO LOGO ANYWHERE. NO TEXT ON THE TEAPOT.

— PRODUCT (FROM IMAGE 1, EXACTLY) —
EXACTLY 1 GLASS TEAPOT: SQUARE BASE TAPERING UPWARD LIKE A PYRAMID, CLEAR TRANSPARENT GLASS BODY,
CLEAR GLASS LOOP HANDLE ON ONE SIDE, A SMALL POURING LIP AT THE OPPOSITE CORNER (NO LONG SPOUT).
SHINY STAINLESS STEEL DOMED LID WITH A FEW SMALL HOLES AND A ROUND STEEL BALL KNOB.
CYLINDRICAL STAINLESS STEEL FINE-MESH INFUSER HANGING INSIDE FROM THE TOP, REACHING ABOUT HALFWAY DOWN.
FILLED WITH CLEAR AMBER-GOLD TEA, GLOWING IN THE WARM LIGHT.
COLOUR: CLEAR GLASS + SILVER STEEL — NOT BLACK, NOT WOOD. NO KNIVES, NO BLOCK, NO HANDLES WITH RIVETS.
NO LOGOS, LETTERS OR DIGITS ON IT.

— SCENE (AS IN IMAGE 2) —
A DARK MOODY KITCHEN WITH A SOFTLY BLURRED BACKGROUND OF SHELVES AND GREEN PLANTS, WARM GOLDEN
LIGHT FROM THE UPPER LEFT, SHALLOW DEPTH OF FIELD. A THICK WOODEN CUTTING BOARD ON A WOODEN TABLE.
THE TEAPOT STANDS ON THE BOARD IN THE CENTRE, SLIGHTLY BELOW THE MIDDLE, ABOUT 40% OF THE WIDTH,
SLIGHT HIGH 3/4 FRONT VIEW. IN FRONT OF IT ON THE BOARD A SMALL HEAP OF DRY LOOSE-LEAF TEA.
LEFT: LEMON SLICES, FRESH MINT, A FEW CINNAMON STICKS. RIGHT: A SMALL JAR OF HONEY, FRESH MINT,
HALF A LEMON, A DARK LINEN TOWEL. REAL CONTACT SHADOWS. PHOTOREALISTIC, NOT 3D RENDER.

— SELF-CHECK —
IS THE IMAGE SQUARE 1:1?
LAYOUT MATCHES IMAGE 2: TOP LINE, BIG SERIF HEADLINE, PILL, SCALLOPED BADGE RIGHT, 3 BENEFITS LEFT,
TORN STICKER RIGHT, DARK STRIP WITH 3 COLUMNS AT THE BOTTOM?
ONLY THE LINES FROM THE TEXT BLOCK, UKRAINIAN, SPELLED EXACTLY, LETTER BY LETTER?
EVERY І HAS A DOT, EVERY Ї HAS TWO DOTS, NO И WHERE І SHOULD BE, NO Ы Э Ъ Ё?
EXACTLY 1 CLEAR GLASS TEAPOT WITH A GLASS HANDLE AND STEEL LID, SAME AS IMAGE 1, NO KNIVES?
NOTHING CLOSER THAN 60 PX TO AN EDGE? NO BUTTON, PRICE, STAR, LOGO OR EXTRA TEXT?
IF NOT — FIX THE LAYOUT OR TEXT, NEVER THE PRODUCT.

— AVOID —
KNIVES · KNIFE BLOCK · SCISSORS · "KITCHEN" LOGO · SECOND TEAPOT · CUPS · RUSSIAN TEXT ·
TEXT FROM IMAGE 2 · EXTRA TEXT · PRICE · DISCOUNT · STARS · BUTTONS · WATERMARKS ·
CROPPED PRODUCT · TEXT AT THE EDGE · OVERLAPPING ELEMENTS · BROKEN WORDS · 3D LOOK · VERTICAL FORMAT
```
