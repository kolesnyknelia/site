# Напрямки пошуку і стоп-лист

## 20 напрямків · 5 слів у кожному

Напрямок = (номер − 1) mod 20 + 1. Слово = (номер − 1) div 20 + 1.
Приклад: номер 37 → напрямок 17, слово 2. Номер 5 → напрямок 5, слово 1.

| # | Напрямок | 1 | 2 | 3 | 4 | 5 |
|---|---|---|---|---|---|---|
| 1 | Кухня: підготовка їжі | vegetable prep tool | egg gadget | dough tool | herb cutter | meat tenderizer gadget |
| 2 | Кухня: зберігання | food storage hack | bag sealer clip | fridge organizer | spice organizer | lunch box gadget |
| 3 | Прибирання | grout cleaning tool | window cleaning gadget | drain hair remover | crevice cleaning brush | dust cleaning gadget |
| 4 | Ванна | shower gadget | bathroom storage no drill | toothbrush holder gadget | hair catcher | towel gadget |
| 5 | Авто | car seat gap filler | car trunk gadget | car cleaning gadget | car cup holder gadget | car door gadget |
| 6 | Собаки | dog paw cleaner | dog walking gadget | dog feeder gadget | dog grooming tool | dog interactive toy |
| 7 | Коти | cat interactive toy | cat grooming glove | cat water fountain accessory | cat window perch | cat litter gadget |
| 8 | Батькам і дітям 3+ | kids drawing toy | kids bath toy | toddler activity board | kids lunch gadget | car seat organizer kids |
| 9 | Сад і дача | garden weeding tool | plant watering gadget | seed planting tool | garden kneeler | plant support gadget |
| 10 | Ремонт та інструменти | magnetic tool gadget | measuring tool gadget | wall repair tool | screw organizer | drill accessory gadget |
| 11 | Догляд без медицини | hair styling gadget | nail tool gadget | makeup organizer | hair accessory novelty | travel beauty gadget |
| 12 | Спорт удома | stretching tool | home workout gadget | posture gadget | grip trainer | jump rope smart |
| 13 | Подорожі | travel organizer | packing gadget | travel pillow novelty | luggage gadget | travel kitchen gadget |
| 14 | Офіс і навчання | desk organizer gadget | cable management | laptop stand gadget | stationery novelty | study gadget |
| 15 | Затишок і світло | motion sensor light | rechargeable night light | under cabinet light | ambient desk lamp | magnetic light |
| 16 | Туризм і риболовля | camping gadget | fishing gadget | outdoor survival tool | camping kitchen | picnic gadget |
| 17 | Порядок у домі | closet organizer gadget | space saving hanger | drawer divider | under bed storage | shoe storage gadget |
| 18 | Прання і догляд за одягом | laundry gadget | shoe cleaning tool | clothes drying gadget | sock organizer | ironing gadget |
| 19 | Блекаут і енергія | rechargeable lantern | power outage gadget | usb rechargeable fan | solar gadget | hand crank gadget |
| 20 | Хобі і подарунки | craft gadget | diy kit adults | gift gadget novelty | puzzle gadget | party gadget |

## Стоп-лист — заїжджена товарка в Україні

Не пропонуй, навіть якщо продажі величезні. Виняток — нова модель, якої на Prom 0–5 продавців (перевір!).

- проектори зоряного неба, лампи-місяці, LED-стрічки, неонові вивіски
- масажери для шиї, масажні пістолети, міостимулятори
- портативні блендери, овочерізки типу Nicer Dicer, ручні подрібнювачі часнику
- ролики й машинки для катишків, вакуумні пакети, силіконові кришки
- швабри-спрей, швабри з відром, прості щітки для унітазу
- бездротові навушники, смарт-годинники, павербанки, зарядки, кабелі
- тримачі телефона в авто (звичайні), автомобільні пилососи
- кігтеточки, прості іграшки-м'ячики для тварин, звичайні шлейки
- органайзери для косметики (прості), дзеркала з підсвіткою
- шапки, рукавички, шкарпетки, термобілизна, пледи з рукавами
- іграшки-антистрес (попіт, сквіш), спінери, слайми
- зволожувачі повітря, аромадифузори
- набори ножів, сковорідки, термокружки
