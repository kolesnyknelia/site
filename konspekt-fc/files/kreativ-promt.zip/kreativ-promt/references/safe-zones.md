# Безопасные зоны и форматы

Разрешения и требования к файлу — из официального гида Meta по форматам объявлений.
Разбивку слепых зон в пикселях Meta таблицей не публикует: цифры ниже — сходящаяся практика
нескольких независимых источников. Порядок величины, а не гарантия; перед крупным запуском
стоит перепроверить.

## Главное различие

**В ленте интерфейс поверх картинки не лежит.** Имя аккаунта рисуется над кадром, кнопка под ним.
Обрезки нет. Поля нужны не для защиты, а для дыхания: текст, прижатый к краю, читается как
ошибка вёрстки, даже когда физически виден целиком.

**В сторис и Reels интерфейс лежит сверху.** Там цифры жёсткие, и у объявления низ съедается
сильнее, чем у обычного поста: добавляется кнопка призыва.

## Холсты

| Плейсмент | Холст | Сверху | Снизу | Бока | Интерфейс поверх |
|---|---|---|---|---|---|
| Лента, вертикаль | 1080 × 1350 (4:5) | 100 | 100 | 100 | нет |
| Лента, квадрат | 1080 × 1080 (1:1) | 100 | 100 | 100 | нет |
| Сторис | 1080 × 1920 (9:16) | 270 | ~420 | 65 | да |
| Reels, объявление | 1080 × 1920 (9:16) | 270 | ~670 | 65 | да |
| Карточка маркетплейса | 1080 × 1440 (3:4) | 60 | 60 | 60 | нет |

Верстать вертикаль по самому тесному варианту — по Reels-объявлению: тогда макет переживёт
и сторис.

**3:4 — это не формат рекламы.** Допуск Meta по пропорции 1%, и 3:4 в него не попадает: лента
обрежет верх и низ. Одна картинка не может работать и на маркетплейсе, и в рекламе — нужны
два экспорта.

## Требования к файлу

- Формат `JPG` или `PNG`, максимум `30 МБ`, минимальная ширина `500 px`
- Рекомендуемое разрешение вертикали в ленте — `1440 × 1800`
- Основной текст объявления `125` символов, заголовок `40`
- Правила «не более 20% текста на картинке» больше нет. Но плотный текст по-прежнему хуже
  работает: он не блокирует показ, он снижает отклик.

## Готовые блоки для промта

Вставляются сразу после шапки-защиты.

### Лента, вертикаль

```
──────── FRAME AND SAFE ZONE ────────
CANVAS 1080 × 1350 PX (4:5) — THE FACEBOOK AND INSTAGRAM FEED FORMAT.
ALL COORDINATES IN THIS BRIEF ARE IN THIS CANVAS SPACE, ORIGIN TOP-LEFT.
THE SAFE ZONE IS X 100 TO 980 AND Y 100 TO 1250.
EVERY LETTER, PANEL, PILL, BADGE, ICON, RULE, ARROW AND SHADOW STAYS FULLY INSIDE THE SAFE
ZONE. NOTHING TOUCHES OR CROSSES THOSE BOUNDS — NOT A CORNER, NOT A TRANSPARENT EDGE, NOT
A GLOW. THE OUTER 100 PX ON ALL FOUR SIDES CARRIES BACKGROUND ONLY.
THE PRODUCT ALSO STAYS INSIDE THE SAFE ZONE AND IS NEVER CROPPED BY THE FRAME.
IF AN ELEMENT DOES NOT FIT INSIDE THESE BOUNDS, SET IT SMALLER OR DROP THE LEAST IMPORTANT
ONE. NEVER PUSH AN ELEMENT OUTWARD AND NEVER LET IT BLEED OFF THE EDGE.
```

### Квадрат
Та же формулировка, заменить две строки:
`CANVAS 1080 × 1080 PX (1:1) — THE SQUARE FEED FORMAT.`
`THE SAFE ZONE IS X 100 TO 980 AND Y 100 TO 980.`

### Сторис и Reels
```
CANVAS 1080 × 1920 PX (9:16) — THE STORIES AND REELS FORMAT.
THE PLATFORM DRAWS ITS OWN INTERFACE OVER THIS IMAGE: THE TOP 270 PX AND THE BOTTOM 670 PX
ARE COVERED BY THE APP AND WILL NOT BE SEEN.
THE SAFE ZONE IS X 65 TO 1015 AND Y 270 TO 1250.
THE AREAS ABOVE Y 270 AND BELOW Y 1250 CARRY BACKGROUND ONLY — THEY MAY HOLD SCENERY AND
COLOUR, BUT NOTHING THE BUYER NEEDS TO READ OR SEE.
```

### Строки в SELF-CHECK
```
IS EVERY ELEMENT FULLY INSIDE THE SAFE ZONE, WITH NOTHING TOUCHING OR CROSSING ITS BOUNDS?
IS THE OUTER MARGIN FREE OF TEXT, PANELS AND ICONS?
IS THE PRODUCT UNCROPPED BY THE FRAME?
```

### Строки в NEGATIVE
```
NO ELEMENT TOUCHING THE FRAME EDGE · NO BLEED OFF THE CANVAS · NO CROPPED PRODUCT ·
NO TEXT IN THE OUTER MARGIN · NO EDGE-TO-EDGE HEADLINE
```

## Словесная страховка

Координаты модель соблюдает лишь отчасти. Словесные формулировки работают заметно лучше:

```
Leave a clean empty border of background around the whole image — about one tenth of the width
on every side. The headline is NOT edge-to-edge: it spans at most 75% of the image width.
If something does not fit, make it smaller — never wider, never closer to the edge.
Before finishing, check every edge: anything closer than 100 px to an edge gets smaller and
moves inward.
```

## Гарантия — только постобработкой

`scripts/safe_fit.py` вписывает готовый креатив в безопасную зону и достраивает поля
растянутым размытым фоном, а не белой рамкой.

```bash
python3 safe_fit.py креатив.jpg --all
```

Получится три файла: `_4x5`, `_1x1`, `_9x16`. Для одного формата — `-f 4x5`.
Компромисс: вписывание уменьшает содержимое. Чтобы заголовок остался крупным, проси в промте
широкие поля словами — тогда скрипту почти нечего будет уменьшать.
