# Шаблоны

Два промта на выходе. Первый — для текстовой модели (ChatGPT, Claude): она разбирает референс
и собирает второй. Второй — для модели-картинки (Nano Banana, Gemini, GPT Image). Если референс
уже разобран, первый можно пропустить и заполнять второй руками.

---

## ШАБЛОН A · промт для текстовой модели (роль арт-директора)

Прикрепить к нему: референс, фото товара, факты. Текст даётся на английском — так модель
стабильнее держит структуру. Отвечать она должна по-русски.

```
YOU ARE AN ART DIRECTOR FOR E-COMMERCE FEED ADS. LESS TEXT WINS: THE AD MUST READ IN ONE
SECOND ON A PHONE. THE IMAGE CARRIES ABOUT 80 PERCENT, THE TEXT ABOUT 20.

I GIVE YOU: A REFERENCE CREATIVE I LIKE, MY PRODUCT PHOTO, AND MY VERIFIED FACTS.

BLOCK 1 · ANALYSIS
- Describe the reference in words precise enough for an image model to rebuild it WITHOUT
  seeing it: setting, where the product sits, headline treatment, panel style, how panels
  connect to parts, colours and their roles, lighting.
- Name which element carries the accent colour and what its single job is.
- Say whether the reference shows the same product as mine. List every part, claim and
  accessory in it that my product does not have — those are DELETED, never adapted.
- Count the reference's text elements and name the noise.

BLOCK 2 · COPY — FIVE TEXT ELEMENTS MAXIMUM
  HEADLINE (STARTS WITH THE PRODUCT NAME) · PILL (the one key spec) ·
  CALLOUT ONE (a part visible in my photo) · CALLOUT TWO (another visible part) ·
  OPTIONAL EYEBROW (two or three words)
No subline, no icon row, no paragraph, no price, no button. Give three A/B variants that
differ by angle, not by wording.

BLOCK 3 · FINISHED PROMPT
Output the complete image-model prompt with variant 1 filled in, in one code block, using
the structure I send next. Complete — never a list of corrections to a previous prompt.

HARD RULES
1. Text inside the image is UKRAINIAN only. Reply to me in Russian.
2. Invent nothing. Every number comes from my facts. Never name a part my product lacks.
3. No painted buttons, carts, "shop" or "buy" text — the platform adds its own button.
4. Start the prompt with FRAME AND SAFE ZONE; ask me the placement first.
5. Forbidden: warranty, delivery, ratings, stars, discounts, "best", "new", "number one",
   certifications, any guarantee or protection my facts do not state.
6. No word broken across lines, no hyphenation.
7. The product keeps its own colour, its own number of pieces and its own markings.
```

---

## ШАБЛОН B · промт для модели-картинки (сценарий A — генерация)

Восемь обязательных частей, порядок не менять. Поля в угловых скобках — заполнить и скобки
убрать.

```
BUILD A FINISHED FACEBOOK AND INSTAGRAM FEED AD AROUND THE PRODUCT IN THE UPLOADED PHOTO.

EVERYTHING IN THIS BRIEF IS A SPECIFICATION, NOT CONTENT TO BE DRAWN. NEVER RENDER ANY PART
OF IT IN THE PICTURE — NO COORDINATES, NO PIXEL VALUES, NO COLOUR CODES, NO FONT NAMES, NO
SECTION HEADINGS, NO FIELD NAMES, NO BRACKETS, NO ANNOTATIONS, NO WATERMARKS. THE ONLY WORDS
AND DIGITS IN THE IMAGE ARE THE LINES IN THE TEXT BLOCK BELOW. NEVER DRAW EMOJI.

──────── FRAME AND SAFE ZONE ────────
CANVAS <1080 × 1350 PX (4:5)>, ORIGIN TOP-LEFT. SAFE ZONE X <100> TO <980>, Y <100> TO <1250>.
EVERY LETTER, PANEL, LINE, ICON AND GLOW STAYS FULLY INSIDE IT. THE OUTER MARGIN CARRIES
BACKGROUND ONLY. THE PRODUCT AND EVERY PART OF IT STAY INSIDE THE FRAME, UNCROPPED.

═══════════ TEXT TO RENDER — <N> LINES, NO MORE ═══════════
CHARACTER FOR CHARACTER. KEEP EVERY UKRAINIAN «І», «Ї», «Є», «Ґ» AND EVERY APOSTROPHE.
EVERY WORD IS WHOLE — NEVER HYPHENATE, NEVER BREAK A WORD ACROSS TWO LINES.

HEADLINE — <COLOUR>:
<Назва товару + ключова вигода>

PILL — <FILL COLOUR>, <TEXT COLOUR>:
<одна характеристика>

CALLOUT ONE — POINTS AT <VISIBLE PART>:
<2–4 слова>

CALLOUT TWO — POINTS AT <ANOTHER VISIBLE PART>:
<2–4 слова>
═══════════════════════════════════════════════════════════

──────── PRODUCT LOCK ────────
THE PRODUCT IS EXACTLY THE ONE IN THE UPLOADED PHOTO: <форма, материал, поверхность, все
части с их количеством>.
IT IS <ЦВЕТ> — NOT <ЧАСТАЯ ПОДМЕНА>, NOT <ВТОРАЯ ПОДМЕНА>. IT HAS EXACTLY <N> PIECES —
NO MORE, NO FEWER. IT HAS NO <ЧЕГО У НЕГО НЕТ> AND NO PRINTED WORDS.
KEEP EVERY PART IN ITS PLACE, NUMBER AND SHAPE. NEVER INVENT LETTERING, LOGOS OR DIGITS
ON IT OR ON ITS DISPLAY.

──────── SCENE ────────
<Место, время суток, свет, направление камеры.>
THE PRODUCT SITS <где> IN THE <какой> PART OF THE FRAME, AT THE SAME ANGLE AS IN THE PHOTO,
LARGE AND SHARP, OCCUPYING ABOUT <N> PERCENT OF THE FRAME HEIGHT.
<Опорные предметы сцены, если нужны: их место и роль.>
<Контровой свет, если товар и фон одной тональности.> TRUE CONTACT SHADOWS.
PHOTOREALISTIC — NO CGI, NO 3D RENDER LOOK. NO SPARKS, NO LIGHTNING, NO LENS FLARES.

──────── TEXT STYLE ────────
TYPEFACE: ONE <heavy condensed sans / heavy rounded-geometric sans / bold grotesque> FOR
EVERYTHING. HEADLINE IN BLACK WEIGHT, EVERYTHING ELSE BOLD.
PANELS: <стиль по таблице яркости фона> — <радиус>, <заливка>, <обводка>, <тень>.
CONNECTOR LINES: THIN, <COLOUR>, ENDING AT THE EDGE OF THE PART — NEVER ON TOP OF IT.
COLOURS: <нейтраль для основного текста>, <акцент> USED ONLY ON <одно место>.
NO OTHER COLOUR ANYWHERE.

──────── ELEMENTS ────────
E1 · HEADLINE — CENTRED ON X <540> · BASELINE Y <205> · ABOUT <96> PX
E2 · PILL — CENTRED ON X <540> · Y <300–380> · FULLY ROUNDED
E3 · CALLOUT ONE — X <110–400>, Y <560–650> · LINE TO <PART>
E4 · CALLOUT TWO — X <690–970>, Y <560–650> · LINE TO <PART>
NO ELEMENT OVERLAPS THE PRODUCT'S KEY PARTS. LINES NEVER CROSS EACH OTHER.

──────── SELF-CHECK ────────
EXACTLY <N> TEXT ELEMENTS AND NOTHING ELSE?
IS THE PRODUCT <ЦВЕТ>, WITH <N> PIECES, IDENTICAL TO THE PHOTO?
IS EVERY ELEMENT INSIDE X <100>–<980>, Y <100>–<1250>?
IS EVERY WORD WHOLE AND SPELLED AS WRITTEN ABOVE?
DOES EVERY CONNECTOR END AT THE EDGE OF ITS PART WITHOUT COVERING IT?
IS THERE ANY BUTTON, CART, PRICE, STAR OR INVENTED LETTERING? IF YES, REMOVE IT.
IF ANY ANSWER IS NO — FIX THE TEXT LAYER OR THE SCENE, NEVER THE PRODUCT.

──────── NEGATIVE ────────
NO <НЕВЕРНЫЙ ЦВЕТ> PRODUCT · NO EXTRA OR MISSING PIECES · NO <ОТСУТСТВУЮЩАЯ ДЕТАЛЬ> ·
NO PRINTED WORDS ON THE PRODUCT · NO EXTRA TEXT · NO SUBLINE · NO BOTTOM ICON ROW ·
NO SHOP BUTTON · NO CART · NO PRICE · NO DISCOUNT · NO STARS · NO RATINGS · NO BADGES ·
NO ELEMENT TOUCHING THE FRAME EDGE · NO CROPPED PRODUCT · NO WORD BROKEN ACROSS LINES ·
NO HYPHENATION · NO RENDERED SPEC TEXT OR COORDINATES · NO EMOJI · NO WATERMARK ·
NO CGI OR 3D RENDER LOOK · NO UNREADABLE TEXT
```

---

## ШАБЛОН C · сценарий B — оверлей поверх готового фото

Товар не перерисовывается вообще. Самый надёжный сценарий, с него стоит начинать.

```
YOU ARE GIVEN ONE PHOTOGRAPH. IT IS THE FINAL IMAGE.

ADD ONLY A TEXT AND PANEL OVERLAY ON TOP OF IT. DO NOT REDRAW, REGENERATE, RELIGHT, RECOLOUR,
RETOUCH, MOVE, SCALE, ROTATE, MIRROR OR RECOMPOSE THE PHOTOGRAPH OR THE PRODUCT IN IT.
EVERY PIXEL OF THE PHOTOGRAPH STAYS AS IT IS. THE PRODUCT KEEPS ITS COLOUR, ITS SHAPE, ITS
NUMBER OF PIECES AND ITS MARKINGS.

EVERYTHING IN THIS BRIEF IS A SPECIFICATION, NOT CONTENT TO BE DRAWN. NEVER RENDER
COORDINATES, PIXEL VALUES, COLOUR CODES, FONT NAMES OR SECTION HEADINGS.

<далее: FRAME AND SAFE ZONE · TEXT TO RENDER · TEXT STYLE · ELEMENTS · SELF-CHECK ·
NEGATIVE — как в шаблоне B, без блоков PRODUCT LOCK и SCENE>

IF A PANEL WOULD COVER THE PRODUCT OR ITS KEY PART, MOVE THE PANEL — NEVER THE PRODUCT.
```

---

## ШАБЛОН D · сценарий C — замена фона, товар и текст сохраняются

На входе два изображения, порядок прикрепления значим: модель различает их только по порядку.

```
YOU ARE GIVEN TWO IMAGES.
IMAGE 1 IS A FINISHED ADVERTISING CREATIVE. IT IS THE MASTER.
IMAGE 2 IS A PHOTOGRAPH OF A <SETTING>. IT IS A BACKGROUND SOURCE AND NOTHING MORE.

REBUILD IMAGE 1 WITH THE <SETTING> FROM IMAGE 2 BEHIND IT. THE PRODUCT AND THE ENTIRE TEXT
LAYER FROM IMAGE 1 ARE COPIED ACROSS UNCHANGED. NOTHING ELSE FROM IMAGE 2 ENTERS THE RESULT.
DO NOT ADD A SINGLE WORD, DIGIT, BADGE, PRICE OR LOGO THAT IS NOT ALREADY IN IMAGE 1.

PHASE 1 — THE PRODUCT IS COPIED PIXEL FOR PIXEL: same body, same colours, same controls,
same parts. Same centre point, same size relative to the canvas, same angle, same tilt.
PHASE 2 — EVERY TEXT ELEMENT IS COPIED UNCHANGED AND IN THE SAME PLACE, spelled character
for character. Every panel keeps its shape, radius, fill, border, opacity and position.
Do not re-typeset, resize, recolour, reposition or translate any of it.
PHASE 3 — FROM IMAGE 2 TAKE THE SETTING AND NOTHING ELSE. Leave out every text, logo,
watermark, person, prop and any other product. Fit the setting to IMAGE 1's canvas — the
background adapts to the canvas, never the canvas to the background. Align its floor line
to the product's base and its horizon to the product's eye level.
PHASE 4 — MATCH THE LIGHT: contact shadow in the same direction as the shadows already in
IMAGE 2, matching colour temperature, a rim along the edge facing the new light. This is a
grade only — the product's shape and colours do not change. The cutout edge is clean: no
halo, no white fringe, no sticker outline. The text layer sits on top, ungraded.

SELF-CHECK: product in the same place, size and angle? every panel and word identical?
anything from IMAGE 2 other than the setting survived? aspect ratio unchanged? edge clean?
IF ANY ANSWER IS NO — FIX THE BACKGROUND, NEVER THE PRODUCT OR THE TEXT.

NEGATIVE: NO MOVED, RESIZED, ROTATED OR REDRAWN PRODUCT · NO RECOLOURED PRODUCT ·
NO INVENTED MARKINGS · NO SECOND PRODUCT · NO RE-TYPESET TEXT · NO MOVED OR RECOLOURED
PANEL · NO TRANSLATED TEXT · NO ADDED WORD OR BADGE · NO TEXT OR WATERMARK FROM IMAGE 2 ·
NO PERSON OR PROP FROM IMAGE 2 · NO CHANGED ASPECT RATIO · NO CROP · NO LETTERBOX BARS ·
NO HALO · NO GRADED TEXT LAYER · NO SHADOWLESS PRODUCT · NO MISMATCHED SHADOW DIRECTION
```

---

## ШАБЛОН E · сценарий D — перенос дизайна референса на своё фото

```
YOU ARE GIVEN TWO IMAGES.
IMAGE 1 IS A DESIGN REFERENCE. TAKE FROM IT ONLY: THE LAYOUT, THE PANEL SHAPES, THE
TYPOGRAPHIC TREATMENT, THE COLOUR ROLES AND THE DECORATIVE DEVICES.
IMAGE 2 IS MY PRODUCT. IT IS THE ONLY PRODUCT IN THE RESULT.

NOTHING ELSE FROM IMAGE 1 ENTERS THE RESULT: NOT ITS PRODUCT, NOT ITS WORDS, NOT ITS
NUMBERS, NOT ITS LOGO, NOT ITS CLAIMS, NOT ITS ACCESSORIES. IF IMAGE 1 SHOWS A PART OR AN
ACCESSORY MY PRODUCT DOES NOT HAVE, IT IS DELETED, NOT ADAPTED.
THE PRODUCT FROM IMAGE 2 KEEPS ITS OWN COLOUR, ITS OWN NUMBER OF PIECES AND ITS OWN SHAPE —
EVEN WHERE IMAGE 1'S PRODUCT LOOKS DIFFERENT.

<далее: FRAME AND SAFE ZONE · TEXT TO RENDER · PRODUCT LOCK · SCENE · TEXT STYLE ·
ELEMENTS · SELF-CHECK · NEGATIVE — как в шаблоне B>

SELF-CHECK ADDITION: DID ANY WORD, DIGIT, LOGO, PART OR ACCESSORY FROM IMAGE 1 SURVIVE?
IF YES, REMOVE IT.
```

---

## Блок для заполнения перед сборкой

Скопировать, заполнить, и только потом собирать промт. Пустое поле — это будущая ошибка.

```
ТОВАР:
ЦВЕТ (точно):
КОЛИЧЕСТВО ПРЕДМЕТОВ:
ЧЕГО У НЕГО НЕТ (частые подмены):
ПРОВЕРЕННЫЕ ХАРАКТЕРИСТИКИ (откуда):
ПЛОЩАДКА И ФОРМАТ:
СЦЕНАРИЙ (A / B / C / D):
СТИЛЕВОЙ КЛЮЧ:
ЯРКОСТЬ ФОНА → СТИЛЬ ПЛАШЕК:
АКЦЕНТ (откуда взят) → ЕГО ЕДИНСТВЕННАЯ РОЛЬ:
ЗАГОЛОВОК (начинается с названия товара):
ПИЛЮЛЯ:
ВЫНОСКА 1 → на какую видимую деталь:
ВЫНОСКА 2 → на какую видимую деталь:
```
