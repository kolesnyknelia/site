#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Снимает проверенные факты с лендинга — из js/product.js.

    python3 facts_from_site.py <папка лендинга>

Печатает сырые факты в том порядке, в котором они нужны для брифа креатива.
Ничего не придумывает: чего нет в product.js, того нет и в выдаче.
Если на машине есть node — читает файл полностью. Если нет — вытаскивает
основные поля регулярками, этого хватает для заголовка и преимуществ.
"""

import json
import os
import re
import shutil
import subprocess
import sys

NODE_DUMP = r"""
const fs = require('fs');
const src = fs.readFileSync(process.argv[1], 'utf8');
let PRODUCT;
eval(src);
process.stdout.write(JSON.stringify(PRODUCT));
"""


def find_product_js(root):
    for path in (os.path.join(root, "js", "product.js"), os.path.join(root, "product.js")):
        if os.path.isfile(path):
            return path
    for dirpath, _dirs, files in os.walk(root):
        if "product.js" in files:
            return os.path.join(dirpath, "product.js")
    return None


def load_with_node(path):
    node = shutil.which("node")
    if not node:
        return None
    try:
        out = subprocess.run([node, "-e", NODE_DUMP, path], capture_output=True, timeout=20)
        if out.returncode == 0 and out.stdout.strip():
            return json.loads(out.stdout)
    except Exception:
        pass
    return None


def load_with_regex(path):
    src = open(path, encoding="utf-8").read()
    data = {}

    def one(key):
        m = re.search(r"\b%s:\s*'([^']*)'" % key, src)
        return m.group(1) if m else None

    def num(key):
        m = re.search(r"\b%s:\s*([0-9]+)" % key, src)
        return int(m.group(1)) if m else None

    def arr(key):
        m = re.search(r"\b%s:\s*\[(.*?)\]" % key, src, re.S)
        return re.findall(r"'([^']*)'", m.group(1)) if m else []

    data["name"] = one("name")
    data["nameSub"] = one("nameSub")
    data["oldPrice"] = num("oldPrice")
    data["newPrice"] = num("newPrice")
    data["benefits"] = arr("benefits")
    data["colors"] = arr("colors")
    data["description"] = {
        "characteristics": arr("characteristics"),
        "content": [
            {"icon": i, "title": t, "text": x}
            for i, t, x in re.findall(
                r"icon:\s*'([^']*)',\s*title:\s*'([^']*)',\s*text:\s*'([^']*)'", src
            )
        ],
    }
    data["_captions"] = re.findall(r"caption:\s*'([^']*)'", src)
    data["seo"] = {"ogTitle": one("ogTitle"), "description": one("description")}
    kb = re.search(r"kitBadge:\s*\{.*?text:\s*'([^']*)'", src, re.S)
    data["kitBadge"] = {"text": kb.group(1)} if kb else {}
    return data


def features(product):
    out = []
    content = (product.get("description") or {}).get("content") or []
    for item in content:
        if isinstance(item, dict) and item.get("title") and item.get("text"):
            out.append((item["title"], item["text"]))
        elif isinstance(item, dict) and item.get("features"):
            for f in item["features"]:
                out.append((f.get("title", ""), f.get("text", "")))
    return out


def captions(product, raw):
    if raw.get("_captions"):
        return raw["_captions"]
    out = []
    for item in (product.get("description") or {}).get("content") or []:
        if isinstance(item, dict) and item.get("caption"):
            out.append(item["caption"])
    return out


def main():
    if len(sys.argv) < 2:
        sys.exit("Укажи папку лендинга: python3 facts_from_site.py <папка>")
    root = sys.argv[1]
    path = find_product_js(root)
    if not path:
        sys.exit("product.js не найден в %s" % root)

    product = load_with_node(path)
    source = "node"
    if product is None:
        product = load_with_regex(path)
        source = "регулярки (node не найден — проверь длинные блоки вручную)"
    raw = load_with_regex(path)

    p = print
    p("ФАКТЫ С САЙТА")
    p("источник: %s" % path)
    p("способ чтения: %s" % source)
    p("")
    p("НАЗВАНИЕ: %s" % (product.get("name") or "—"))
    p("ПОДЗАГОЛОВОК САЙТА: %s" % (product.get("nameSub") or "—"))
    kit = (product.get("kitBadge") or {})
    if kit.get("text"):
        p("КОМПЛЕКТ: %s" % kit["text"])
    colors = product.get("colors") or []
    p("ЦВЕТА НА ВЫБОР: %s" % (", ".join(map(str, colors)) if colors else "выбора нет"))
    p("ЦЕНА: %s грн (старая %s)" % (product.get("newPrice") or "—", product.get("oldPrice") or "—"))
    promo = product.get("promo") or {}
    for tier in promo.get("tiers") or []:
        p("АКЦИЯ: %s шт — минус %s грн" % (tier.get("qty"), tier.get("discount")))
    p("")
    p("ПРЕИМУЩЕСТВА (блок benefits — формулировки владельца):")
    for b in product.get("benefits") or []:
        p("  · %s" % b)
    p("")
    p("ЦИФРЫ И СВОЙСТВА (блок иконок — лучший источник для выносок):")
    for title, text in features(product):
        p("  · %s — %s" % (title, text))
    p("")
    p("ПОДПИСИ ПОД ФОТО (короткие и уже проверенные фразы):")
    for c in captions(product, raw):
        p("  · %s" % c)
    p("")
    p("ХАРАКТЕРИСТИКИ (таблица):")
    for ch in (product.get("description") or {}).get("characteristics") or []:
        p("  · %s" % ch.replace("|", "—"))
    p("")
    seo = product.get("seo") or {}
    p("OG-ЗАГОЛОВОК (готовый крючок с сайта): %s" % (seo.get("ogTitle") or "—"))
    p("")
    imgs = []
    for sub in ("img", "images"):
        d = os.path.join(root, sub)
        if os.path.isdir(d):
            imgs += sorted(f for f in os.listdir(d) if f.lower().endswith((".jpg", ".jpeg", ".png", ".webp")))
    p("ФОТО В ПАПКЕ: %s" % (", ".join(imgs) if imgs else "—"))
    p("")
    p("ЧЕГО ЗДЕСЬ НЕТ — того нет и в креативе. Гарантии, сроки доставки, сертификаты,")
    p("рейтинги и «лучший на рынке» не берём, даже если очень хочется.")


if __name__ == "__main__":
    main()
