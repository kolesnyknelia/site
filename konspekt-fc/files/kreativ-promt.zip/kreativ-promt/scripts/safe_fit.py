#!/usr/bin/env python3
"""
Приводит готовый креатив к формату Meta с соблюдением безопасных зон.

Вписывает всё содержимое картинки внутрь безопасной зоны целевого холста,
а поля вокруг достраивает продолжением краёв — не белой рамкой, а размытым
растянутым фоном, чтобы шва не было видно.

Использование:
    python3 safe_fit.py креатив.jpg
    python3 safe_fit.py креатив.jpg --format 1x1
    python3 safe_fit.py креатив.jpg --format 9x16
    python3 safe_fit.py креатив.jpg --all

Форматы:
    4x5   1080x1350, безопасная зона X 100-980,  Y 100-1250   (лента, основной)
    1x1   1080x1080, безопасная зона X 100-980,  Y 100-980    (лента, квадрат)
    9x16  1080x1920, безопасная зона X 65-1015,  Y 270-1250   (сторис и Reels)
"""
import argparse, os, sys
from PIL import Image, ImageFilter

FORMATS = {
    "4x5":  dict(canvas=(1080, 1350), safe=(100, 100, 980, 1250)),
    "1x1":  dict(canvas=(1080, 1080), safe=(100, 100, 980, 980)),
    "9x16": dict(canvas=(1080, 1920), safe=(65, 270, 1015, 1250)),
}


def build_backdrop(src, canvas):
    """Фон под поля: исходник, растянутый на весь холст и размытый."""
    cw, ch = canvas
    scale = max(cw / src.width, ch / src.height)
    w, h = int(src.width * scale + 0.5), int(src.height * scale + 0.5)
    bg = src.resize((w, h), Image.LANCZOS)
    bg = bg.crop(((w - cw) // 2, (h - ch) // 2,
                  (w - cw) // 2 + cw, (h - ch) // 2 + ch))
    return bg.filter(ImageFilter.GaussianBlur(radius=max(cw, ch) // 22))


def fit(path, fmt, suffix=True):
    spec = FORMATS[fmt]
    cw, ch = spec["canvas"]
    sx0, sy0, sx1, sy1 = spec["safe"]
    sw, sh = sx1 - sx0, sy1 - sy0

    src = Image.open(path)
    if src.mode != "RGB":
        src = src.convert("RGB")

    # вписываем целиком в безопасную зону, пропорции не трогаем
    scale = min(sw / src.width, sh / src.height)
    nw, nh = max(1, int(src.width * scale)), max(1, int(src.height * scale))
    content = src.resize((nw, nh), Image.LANCZOS)

    out = build_backdrop(src, (cw, ch))
    out.paste(content, (sx0 + (sw - nw) // 2, sy0 + (sh - nh) // 2))

    stem, ext = os.path.splitext(path)
    dst = f"{stem}_{fmt}.jpg" if suffix else path
    out.save(dst, "JPEG", quality=94, subsampling=0)
    return dst, (nw, nh)


def main():
    ap = argparse.ArgumentParser(description="Подгонка креатива под безопасные зоны Meta")
    ap.add_argument("image", help="путь к готовому креативу")
    ap.add_argument("--format", "-f", default="4x5", choices=list(FORMATS),
                    help="целевой формат (по умолчанию 4x5)")
    ap.add_argument("--all", action="store_true", help="сделать все три формата")
    a = ap.parse_args()

    if not os.path.exists(a.image):
        sys.exit(f"нет файла: {a.image}")

    targets = list(FORMATS) if a.all else [a.format]
    for fmt in targets:
        dst, (nw, nh) = fit(a.image, fmt)
        cw, ch = FORMATS[fmt]["canvas"]
        print(f"{fmt:5} -> {dst}   холст {cw}x{ch}, содержимое {nw}x{nh}")


if __name__ == "__main__":
    main()
